package com.huzu.easytpa;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TPDenyCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) return true;
        Player target = (Player) sender;

        if (!EasyTPA.requests.containsKey(target.getUniqueId())) {
            target.sendMessage(ChatColor.RED + "받은 텔레포트 요청이 없습니다!");
            return true;
        }

        Player requester = target.getServer().getPlayer(EasyTPA.requests.get(target.getUniqueId()));

        if (requester != null)
            requester.sendMessage(ChatColor.RED + target.getName() + "님이 텔레포트 요청을 거절했습니다.");

        target.sendMessage(ChatColor.YELLOW + "텔레포트 요청을 거절했습니다.");
        EasyTPA.requests.remove(target.getUniqueId());

        return true;
    }
}
