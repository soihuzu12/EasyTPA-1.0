package com.huzu.easytpa;

import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.UUID;

public class EasyTPA extends JavaPlugin {

    public static HashMap<UUID, UUID> requests = new HashMap<>();
    public static HashMap<UUID, Long> requestTime = new HashMap<>();

    @Override
    public void onEnable() {
        getCommand("티피요청").setExecutor(new TPACommand());
        getCommand("티피수락").setExecutor(new TPAccCommand());
        getCommand("티피거절").setExecutor(new TPDenyCommand());

        getLogger().info("EasyTPA 플러그인 활성화!");
    }

    @Override
    public void onDisable() {
        getLogger().info("EasyTPA 플러그인 비활성화.");
    }
}
