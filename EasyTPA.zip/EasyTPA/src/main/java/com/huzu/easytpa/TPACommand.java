package com.huzu.easytpa;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TPACommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "/티피요청 <플레이어>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "플레이어를 찾을 수 없습니다!");
            return true;
        }

        if (target == player) {
            player.sendMessage(ChatColor.RED + "자기 자신에게 요청할 수 없습니다!");
            return true;
        }

        EasyTPA.requests.put(target.getUniqueId(), player.getUniqueId());
        EasyTPA.requestTime.put(target.getUniqueId(), System.currentTimeMillis());

        player.sendMessage(ChatColor.GREEN + target.getName() + "님에게 텔레포트 요청을 보냈습니다.");
        target.sendMessage(ChatColor.YELLOW + player.getName() + "님이 텔레포트 요청을 보냈습니다!");
        target.sendMessage(ChatColor.GOLD + "/티피수락 : 수락   /티피거절 : 거절");

        return true;
    }
}
